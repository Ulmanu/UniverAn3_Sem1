package com.forezp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootJmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootJmsApplication.class, args);
	}
}
