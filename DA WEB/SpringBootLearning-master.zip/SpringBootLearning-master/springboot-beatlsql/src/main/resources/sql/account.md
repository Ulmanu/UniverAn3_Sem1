selectAccountByName
===
*根据name获account

    select * from account where name= #name#

   
