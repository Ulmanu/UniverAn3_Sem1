package com.endava.internship.collections;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class StudentList<T> implements List<T> {


    private T[] stud;

    StudentList() {
        this.stud = (T[]) new Object[0];
    }

    @Override
    public int size() {
        return stud.length;
    }

    @Override
    public boolean isEmpty() {
        return stud.length == 0;
    }

    @Override
    public boolean contains(Object o) {
        for (int j = 0; j < stud.length; j++)
            if (stud[j].equals(o)) {
                return true;
            }
        return false;
    }

    @Override
    public Iterator<T> iterator() {
        return new StudentIterator(stud);
    }

    @Override
    public Object[] toArray() {
        T[] valstud = stud;
        return valstud;
    }

    @Override
    public <T> T[] toArray(T[] ts) {
        ts = (T[]) stud;
        System.out.println("toArray with generics");
        return ts;
    }

    @Override
    public boolean add(T t) {
        T[] temp = stud;
        stud = (T[]) new Object[temp.length + 1];
        System.arraycopy(temp, 0, stud, 0, temp.length);
        stud[stud.length - 1] = t;
        System.out.println("Add student");
        return true;
    }

    @Override
    public boolean remove(Object o) {
        int j, k = 0;

        while (k < stud.length) {
            j = 0;
            while (j < stud.length) {
                if (stud[j].equals(o)) {
                    T[] temp = stud;
                    stud = (T[]) new Object[temp.length - 1];
                    System.arraycopy(temp, 0, stud, 0, j);

                    int countAfterIndex = temp.length - j - 1;
                    System.arraycopy(temp, j + 1, stud, j, countAfterIndex);
                    System.out.println("Remove by index");
                }
                j++;
            }
            k++;
        }
        return true;
    }

    @Override
    public void clear() {
        System.out.println("List clear");
        this.stud = (T[]) new Object[0];
    }

    @Override
    public T get(int i) {
        if ((i > stud.length) || (i < 0)) {
            throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        }
        return stud[i];
    }

    @Override
    public void add(int index, T student) {
        if ((index > stud.length) || (index < 0)) {
            throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        }
        T[] temp = stud;
        stud = (T[]) new Object[temp.length + 1];
        System.arraycopy(temp, 0, stud, 0, index);

        int countAfterIndex = temp.length - index;
        System.arraycopy(temp, index, stud, index + 1, countAfterIndex);
        stud[index] = (T) student;
        System.out.println("Student was added");

    }

    public T set(int i, T student) {
        if ((i > stud.length) || (i < 0)) {
            throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        }

        stud[i] = student;
        System.out.println("Set new value");
        return stud[i];
    }

    @Override
    public T remove(int i) {
        if ((i > stud.length) || (i < 0)) {
            throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        }
        T[] temp = stud;
        stud = (T[]) new Object[temp.length - 1];
        System.arraycopy(temp, 0, stud, 0, i);
        int countAfterIndex = temp.length - i - 1;
        System.arraycopy(temp, i + 1, stud, i, countAfterIndex);
        System.out.println("Remove by index");
        return null;
    }

    @Override
    public int indexOf(Object o) {
        int j = 0;

        while (j < stud.length) {
            if (stud[j].equals(o)) {
                return j;
            }
            j++;
        }
        return -1;
    }

    @Override
    public int lastIndexOf(Object o) {
        int j = 0, k = -1;

        while (j < stud.length) {
            if (stud[j].equals(o)) {
                k = j;
            }
            j++;
        }
        return k;
    }

    @Override
    public ListIterator<T> listIterator() {
        return new StudentListIterator(stud);
    }

    @Override
    public ListIterator<T> listIterator(int i) {
        if ((i > stud.length) || (i < 0)) {
            throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        }
        return new StudentListIterator(stud, i);
    }

    @Override
    public List<T> subList(int fromIndex, int toIndex) {
        if (((fromIndex > stud.length) || (toIndex > stud.length)) || ((fromIndex < 0) || (toIndex < 0))) {
            throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        }
        T[] temp = stud;
        Student[] stud1 = new Student[temp.length - (temp.length - toIndex) - fromIndex];
        System.arraycopy(temp, fromIndex, stud1, 0, toIndex - fromIndex);

        return (List<T>) Arrays.asList(stud1);
    }

    @Override
    public boolean addAll(Collection<? extends T> collection) {
        T[] temp = stud;
        stud = (T[]) new Student[temp.length + collection.size()];
        System.arraycopy(temp, 0, stud, 0, temp.length);
        int k = 0;
        for (int j = temp.length; j < stud.length; j++) {
            stud[j] = (T) collection.toArray()[k];
            System.out.println("Add student");
            k++;
        }
        return true;
    }

    @Override
    public boolean containsAll(Collection<?> collection) {
        int j;
        for (int i = 0; i < collection.size(); i++) {
            for (j = 0; j < stud.length; j++)
                if (collection.toArray()[i] == stud[j])
                    break;

            if (j == stud.length)
                return false;
        }
        return true;

    }

    @Override
    public boolean addAll(int i, Collection<? extends T> collection) {
        if ((i > stud.length) || (i < 0)) {
            throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        }
        T[] temp = stud;
        stud = (T[]) new Student[temp.length + collection.size()];
        System.arraycopy(temp, 0, stud, 0, i);
        int k = 0;
        for (int j = i; j < i + collection.size(); j++) {
            stud[j] = (T) collection.toArray()[k];
            System.out.println("Add student");
            k++;
        }
        int elementsAfterIndex;
        elementsAfterIndex = stud.length - (i + collection.size());
        System.arraycopy(temp, i, stud, i + collection.size(), elementsAfterIndex);
        return true;
    }

    @Override
    public boolean removeAll(Collection<?> collection) {
        int j;
        for (int k = 0; k < collection.size(); k++)
            for (int i = 0; i < collection.size(); i++) {

                for (j = 0; j < stud.length; j++)
                    if (collection.toArray()[i] == stud[j]) {
                        T[] temp = stud;
                        stud = (T[]) new Student[temp.length - 1];
                        System.arraycopy(temp, 0, stud, 0, j);
                        int countAfterIndex = temp.length - j - 1;
                        System.arraycopy(temp, j + 1, stud, j, countAfterIndex);
                        System.out.println("Remove by index");
                        break;
                    }

                if (j == stud.length)
                    return false;
            }
        return true;
    }

    @Override
    public boolean retainAll(Collection<?> collection) {
        int count = 0;
        ArrayList<Integer> index = new ArrayList<>();
        for (int i = 0; i < collection.size(); i++) {
            for (int j = 0; j < stud.length; j++)
                if ((stud[j].equals(collection.toArray()[i])) && (!index.contains(j))) {
                    count++;
                    index.add(j);
                }
        }
        Student[] temp = new Student[count];
        int l = 0;
        for (Integer ok : index) {

            for (int j = 0; j < stud.length; j++) {
                if (ok == j) {
                    temp[l] = (Student) stud[j];
                }
            }
            l++;
        }
        stud = (T[]) new Student[count];
        stud = (T[]) temp;
        return true;

    }
}
