package com.endava.internship.collections;

import java.util.Iterator;

public class StudentIterator<T> implements Iterator<T> {
    private int index = 0;
    T[] stud;

    StudentIterator(T[] stud) {
        this.stud = stud;
    }

    @Override
    public boolean hasNext() {
        return index < stud.length;
    }

    @Override
    public T next() {
        if ((index) >= stud.length) throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        return stud[index++];
    }
}
