package com.endava.internship.collections;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

public class StudentTest {
    public static void main(String[] args) {

        try {
            StudentList list = new StudentList();
            Student stud1 = new Student("Petru", LocalDate.of(2001, 1, 1), "moldovan");
            Student stud2 = new Student("Petru1", LocalDate.of(2000, 1, 1), "moldovan1");
            Student stud3 = new Student("Petru2", LocalDate.of(1997, 1, 1), "moldovan2");
            Student stud4 = new Student("Petru3", LocalDate.of(1999, 1, 1), "moldovan3");

            list.add(stud1);
            list.add(stud2);
            list.add(stud3);
            list.add(stud4);

            System.out.println("List size:" + list.size());


            System.out.println("Get element by id");
            System.out.println(list.get(1));

            System.out.println("is the list empty:" + list.isEmpty());
            list.clear();
            System.out.println("is the list empty:" + list.isEmpty());
            Student stud5 = new Student("Petru5", LocalDate.of(1999, 1, 1), "moldovan5");

            System.out.println("List contains: " + list.contains(stud2));

        /*
          Add by index
         */
            System.out.println("Add index");
            list.add(1, stud5);
        /*
          Set by index
         */
            System.out.println("Set by index");
            list.set(0, stud5);

            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            }


            list.add(3, stud5);

            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            }

        /*
            Remove by index
         */
            list.remove(3);
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            }

        /*
          Clear list
         */
      /*  list.clear();
        System.out.println(list.size());*/

        /*
        Remove by object
         */
            list.add(stud3);
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            }

            list.add(4, stud5);
            System.out.println("Delete by object");
            list.remove(stud5);
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            }


            Object[] studlist = list.toArray();

            for (Object s : studlist) {
                System.out.println(s);
            }

            Object[] studl = new Student[list.size()];
            studl = list.toArray(studl);

            for (Object s : studl) {
                System.out.println(s);
            }

        /*
          indexOf and lastIndexOf
         */
            System.out.println(list.indexOf(stud3));
            System.out.println(list.lastIndexOf(stud3));

        /*
          Iterator
         */
            System.out.println("Using iterator");
            Iterator<Student> lstud = list.iterator();
            int j = 0;
            while (lstud.hasNext()) {
                System.out.println(lstud.next());
                System.out.println(j);
                j++;
            }

        /*
          Listiterator
         */
            System.out.println("Using list iterator");
            ListIterator<Student> listud = list.listIterator();
            while (listud.hasNext()) {
                System.out.println(listud.next());
            }


        /*
          Listiterator with i
         */
            System.out.println("Using list iterator with i");

            ListIterator<Student> listudi = list.listIterator(2);
            while (listudi.hasPrevious()) {
                System.out.println(listudi.previous());

            }
            System.out.println(listudi.nextIndex());
            ListIterator<Student> listudi2 = list.listIterator(2);
            System.out.println("Has next");
            while (listudi2.hasNext()) {
                System.out.println(listudi2.next());

            }

        /*
          Sublist
         */
            System.out.println("Sublist");
            List<Student> sublist = list.subList(2, 4);
            for (Student s : sublist) {
                System.out.println(s.getName());
            }


            List<Student> list2 = new ArrayList<>();
            Student studl1 = new Student("Roman", LocalDate.of(2001, 1, 1), "rus");
            Student studl2 = new Student("Roman1", LocalDate.of(2000, 1, 1), "rus");
            Student studl3 = new Student("Roman2", LocalDate.of(1997, 1, 1), "rus");
            Student studl4 = new Student("Roman3", LocalDate.of(1997, 1, 1), "rus");
            list2.add(studl1);
            list2.add(studl2);
            list2.add(studl3);
            list2.add(studl3);

        /*
          Addall
         */
            System.out.println("AddAll");
            list.addAll(list2);
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            }
        /*
          Contains All
         */
            System.out.println("list containsAll elements:" + list.containsAll(list2));
            // list2.add(studl4);
            System.out.println("list containsAll elements:" + list.containsAll(list2));

        /*
          AddAll by index
         */
            System.out.println("AddAll by index");
            //  list.addAll(3, list2);
            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            }

        /*
          Remove All
         */
      /*  list.removeAll(list2);
          for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }*/

        /*
          Retain All
         */
            System.out.println("Retain all");
            list.retainAll(list2);

            for (int i = 0; i < list.size(); i++) {
                System.out.println(list.get(i));
            }

        } catch (ArrayIndexOutOfBoundsException ex) {
            System.out.println("Index is too big");

        }

    }


}
