package com.endava.internship.collections;

import java.util.ListIterator;

public class StudentListIterator<T> implements ListIterator<T> {

    private int index = 0;
    T[] stud;

    StudentListIterator(T[] stud) {
        this.stud = (T[]) stud;
    }

    StudentListIterator(T[] stud, int i) {
        this.stud = (T[]) stud;
        this.index = i;
    }

    @Override
    public boolean hasNext() {
        return index < stud.length;
    }

    @Override
    public T next() {
        if ((index) >= stud.length) throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        return stud[index++];
    }

    @Override
    public boolean hasPrevious() {
        return index > 0;
    }

    @Override
    public T previous() {
        if ((index) < 0) throw new ArrayIndexOutOfBoundsException("Index Out of Bounds");
        return stud[index--];
    }

    @Override
    public int nextIndex() {
        return ++index;
    }

    @Override
    public int previousIndex() {
        return --index;
    }

    @Override
    public void remove() {

    }

    @Override
    public void set(Object o) {

    }

    @Override
    public void add(Object o) {

    }
}
